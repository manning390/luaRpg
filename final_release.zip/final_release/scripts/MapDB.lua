-- assert(CreateHouseMap)
-- assert(CreateJailMap)
-- assert(CreateSewerMap)
-- assert(CreateArenaMap)
assert(CreateTownMap)
assert(CreateWorldMap)
assert(CreateCaveMap)
MapDB = {
    -- ["player_house"] = CreateHouseMap,
    -- ["jail"] = CreateJailMap,
    -- ["sewer"] = CreateSewerMap,
    -- ["arena"] = CreateArenaMap,
    ["town"] = CreateTownMap,
    ["world"] = CreateWorldMap,
    ["cave"] = CreateCaveMap,
}
