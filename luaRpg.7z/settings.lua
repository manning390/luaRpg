
name = "Lua RPG"
width = 256*2
height = 224*2
manifest = "manifest.lua"

--
-- This script is expected to be an asset in the manifest file.
-- It's executed at the start
--
main_script = "main.lua"
on_update = "update()"

webserver = true
